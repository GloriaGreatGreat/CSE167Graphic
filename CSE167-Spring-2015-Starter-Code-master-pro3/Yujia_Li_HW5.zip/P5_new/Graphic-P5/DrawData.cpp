#include "DrawData.h"


DrawData::DrawData(void)
{
    //
}

DrawData::~DrawData(void)
{
    //
}
